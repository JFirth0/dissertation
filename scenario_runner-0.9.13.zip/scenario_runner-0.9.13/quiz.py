import tkinter as tk
from tkinter import ttk
import time
import json

class QuizPage:
    def __init__(self, root, question_data, on_submit, scenario_name, autonomy_level, scenario_completed):
        self.root = root
        self.question_data = question_data
        self.selected_option = tk.StringVar()

        self.on_submit = on_submit

        self.create_quiz_page()

        self.quiz_data_handler = QuizData()

        self.scenario_name = scenario_name
        self.autonomy_level = autonomy_level
        self.scenario_completed = scenario_completed 
        self.quiz_start_time = time.time()


    def create_quiz_page(self):
        # Create and configure the quiz frame
        self.quiz_frame = ttk.Frame(self.root)
        self.quiz_frame.pack(fill=tk.BOTH, expand=True)

        self.selected_options = []

        # Add widgets to display quiz questions and options
        for question_data in self.question_data:
            question_label = ttk.Label(self.quiz_frame, text=question_data['question'], font=('Helvetica', 10, 'bold'))
            question_label.pack()

            selected_option = tk.StringVar()
            self.selected_options.append(selected_option)

            # Add radio buttons for each option
            for option in question_data['options']:
                option_button = ttk.Radiobutton(self.quiz_frame, text=option, variable=selected_option, value=option)
                option_button.pack(anchor=tk.W)

        self.submit_button = ttk.Button(self.quiz_frame, text="Submit", command=self.submit_quiz)
        self.submit_button.pack(pady=10)

        
    def submit_quiz(self):
        
        end_time = time.time()
        
        scenario_name = self.scenario_name  
        autonomy_level = self.autonomy_level 
        scenario_completed = self.scenario_completed
        correct_answers = self.answers_count()
        total_quiz_time = end_time - self.quiz_start_time

        # Prepare results data
        result_data = {
            "scenario_name": scenario_name,
            "autonomy_level": autonomy_level,
            "scenario_completed": scenario_completed,
            "quiz_results": {
                "total_questions": len(self.question_data),
                "correct_answers": correct_answers,
                "total_time": total_quiz_time,
            },
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }

        # Save results using QuizData
        self.quiz_data_handler.save_results(result_data)

        # Destroy the quiz frame after submission
        self.quiz_frame.destroy()

    def answers_count(self):
        correct_count = 0
        for i, question_data in enumerate(self.question_data):
            selected = self.selected_options[i].get()
            if selected == question_data["answer"]:
                correct_count += 1
        return correct_count    
    

class QuizData:
    
    def __init__(self, results_file="results.json"):
        self.results_file = results_file
        open(self.results_file, 'a').close()

    def save_results(self, result_data):
        """Saves results data to results.json file"""
        try:
            with open(self.results_file, 'r') as file:
                existing_data = json.load(file)
        except (FileNotFoundError, json.decoder.JSONDecodeError):
            existing_data = []

        existing_data.append(result_data)

        with open(self.results_file, 'w') as file:
            json.dump(existing_data, file, indent=4)  