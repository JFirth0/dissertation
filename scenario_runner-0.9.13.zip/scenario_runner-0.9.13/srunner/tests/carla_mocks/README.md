carla.py is a CARLA mock module that allows to execute unittests without a CARLA installation or running instance.

Remark:
agents/ is a 1:1 copy from CARLA