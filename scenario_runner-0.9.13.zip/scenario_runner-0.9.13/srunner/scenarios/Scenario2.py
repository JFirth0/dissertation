from __future__ import print_function

import py_trees
import carla

from agents.navigation.local_planner import RoadOption
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import WaypointFollower

from srunner.scenariomanager.carla_data_provider import CarlaDataProvider
from srunner.scenariomanager.scenarioatomics.atomic_trigger_conditions import DriveDistance
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import Idle
from srunner.tools.scenario_helper import get_location_in_distance_from_wp
from srunner.scenarios.object_crash_vehicle import StationaryObjectCrossing
from srunner.tools.scenario_helper import generate_target_waypoint
  
from srunner.scenariomanager.scenarioatomics.atomic_behaviors import  ActorDestroy, ActorSource, StopVehicle, ActorSink, ActorTransformSetter



class Scenario2(StationaryObjectCrossing):

    """
    This class holds everything required for a construction scenario
    The ego vehicle is passing through a road and encounters
    a stationary rectangular construction cones setup and traffic warning.

    The vehicle should stop before it.

    This is a single ego vehicle scenario
    """

    def __init__(
            self,
            world,
            ego_vehicles,
            config,
            randomize=False,
            debug_mode=False,
            criteria_enable=True,
            timeout=60):
        """
        Setup all relevant parameters and create scenario
        """
        super(
            Scenario2,
            self).__init__(
            world,
            ego_vehicles=ego_vehicles,
            config=config,
            randomize=randomize,
            debug_mode=debug_mode,
            criteria_enable=criteria_enable)

    def _initialize_actors(self, config):
        """
        Custom initialization
        """
        self._other_actor_transform = config.other_actors[0].transform
        first_vehicle_transform = carla.Transform(
            carla.Location(config.other_actors[0].transform.location.x,
                           config.other_actors[0].transform.location.y,
                           config.other_actors[0].transform.location.z - 500),
            config.other_actors[0].transform.rotation)
        first_vehicle = CarlaDataProvider.request_new_actor(config.other_actors[0].model, self._other_actor_transform)
        first_vehicle.set_transform(first_vehicle_transform)
        first_vehicle.set_simulate_physics(enabled=False)
        self.other_actors.append(first_vehicle)

        _start_distance = 40
        lane_width = self._reference_waypoint.lane_width
        location, _ = get_location_in_distance_from_wp(
            self._reference_waypoint, _start_distance)
        waypoint = self._wmap.get_waypoint(location)
        self._create_construction_setup(waypoint.transform, lane_width)
        self._ego_max_brake = 1.0
        self._other_actor_transform = None
        self._blackboard_queue_name = 'SignalizedJunctionLeftTurn/actor_flow_queue'

    def create_cones_side(
            self,
            start_transform,
            forward_vector,
            z_inc=0,
            cone_length=0,
            cone_offset=0):
        """
        Creates One Side of the Cones
        """
        _dist = 0
        while _dist < (cone_length * cone_offset):
            # Move forward
            _dist += cone_offset
            forward_dist = carla.Vector3D(0, 0, 0) + forward_vector * _dist

            location = start_transform.location + forward_dist
            location.z += z_inc
            transform = carla.Transform(location, start_transform.rotation)

            cone = CarlaDataProvider.request_new_actor(
                'static.prop.constructioncone', transform)
            cone.set_simulate_physics(True)
            self.other_actors.append(cone)

    def _create_construction_setup(self, start_transform, lane_width):
        """
        Create Construction Setup
        """

        _initial_offset = {'cones': {'yaw': 180, 'k': lane_width / 2.0},
                           'warning_sign': {'yaw': 180, 'k': 5, 'z': 0},
                           'debris': {'yaw': 0, 'k': 2, 'z': 1}}
        _prop_names = {'warning_sign': 'static.prop.trafficwarning',
                       'debris': 'static.prop.dirtdebris02'}

        _perp_angle = 90
        _setup = {'lengths': [0, 6, 3], 'offsets': [0, 2, 1]}
        _z_increment = 0.1

        ############################# Traffic Warning and Debris ##############
        for key, value in _initial_offset.items():
            if key == 'cones':
                continue
            transform = carla.Transform(
                start_transform.location,
                start_transform.rotation)
            transform.rotation.yaw += value['yaw']
            transform.location += value['k'] * \
                transform.rotation.get_forward_vector()
            transform.location.z += value['z']
            transform.rotation.yaw += _perp_angle
            static = CarlaDataProvider.request_new_actor(
                _prop_names[key], transform)
            static.set_simulate_physics(True)
            self.other_actors.append(static)

        ############################# Cones ###################################
        side_transform = carla.Transform(
            start_transform.location,
            start_transform.rotation)
        side_transform.rotation.yaw += _perp_angle
        side_transform.location -= _initial_offset['cones']['k'] * \
            side_transform.rotation.get_forward_vector()
        side_transform.rotation.yaw += _initial_offset['cones']['yaw']

        for i in range(len(_setup['lengths'])):
            self.create_cones_side(
                side_transform,
                forward_vector=side_transform.rotation.get_forward_vector(),
                z_inc=_z_increment,
                cone_length=_setup['lengths'][i],
                cone_offset=_setup['offsets'][i])
            side_transform.location += side_transform.get_forward_vector() * \
                _setup['lengths'][i] * _setup['offsets'][i]
            side_transform.rotation.yaw += _perp_angle

    def _create_behavior(self):
        sequence = py_trees.composites.Sequence("Navigate Obstruction")
        
        

        # 1.Drive for a Distance
        drive_distance = DriveDistance(self.ego_vehicles[0], distance=2)  
        sequence.add_child(drive_distance)
        

        # 2.Detect Construction 
        construction_trigger = DriveDistance(self.ego_vehicles[0], distance=5)  
        sequence.add_child(construction_trigger) 

        # 3.Stop 
        sequence.add_child(StopVehicle(self.ego_vehicles[0], self._ego_max_brake))

        return sequence 