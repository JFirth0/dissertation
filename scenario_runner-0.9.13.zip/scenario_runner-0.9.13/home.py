import tkinter as tk
from tkinter import ttk
import threading
import subprocess
import os
import json
from PIL import Image, ImageTk

from quiz import QuizPage, QuizData

class HomePage:
    def __init__(self, root):
        self.root = root
        self.root.title("Scenario Runner GUI")
        self.quiz_shown = False
        
        # Set window size
        self.root.geometry("710x300")

        
        # Create scenario label
        self.scenario_label = ttk.Label(root, text="Scenario:")
        self.scenario_label.place(relx=0.3, rely=0.4, anchor=tk.E)
        
        # Create scenario options
        self.scenario_options = ["Scenario1", "Scenario2", "Scenario3"]  # Add more scenarios as needed
        
        # Create scenario combobox
        self.scenario_combobox = ttk.Combobox(root, values=self.scenario_options, width=30)
        self.scenario_combobox.place(relx=0.6, rely=0.4, anchor=tk.CENTER)
        self.scenario_combobox.set(self.scenario_options[0])  # Set default value
        
        # Create run scenario button
        self.run_scenario_button = ttk.Button(root, text="Run Scenario", command=self.run_scenario)
        self.run_scenario_button.place(relx=0.5, rely=0.6, anchor=tk.CENTER)

        # Create run manual control button
        self.run_manual_control_button = ttk.Button(root, text="Run Manual Control", command=self.run_manual_control)
        self.run_manual_control_button.place(relx=0.5, rely=0.7, anchor=tk.CENTER)
        
    def run_scenario(self):
        scenario = self.scenario_combobox.get()
        command = ["python", "scenario_runner.py", "--reloadWorld"]
        
        if scenario:
            command.extend(["--scenario", scenario])
        
        self.run_subprocess(command)

    def run_manual_control(self):
        # Run the manual control subprocess in a separate thread
        threading.Thread(target=self.run_subprocess, args=(["python", "manual_control.py"],)).start()

    def run_subprocess(self, command):
        try:
            process = subprocess.Popen(command)
            while process.poll() is None:
                self.root.update()
        
            # Check if the process was for running a scenario
            if "scenario_runner.py" in command:
                print("Scenario process completed successfully!")
                self.quiz_shown = False 
                self.show_quiz() 
            else:
                print("Manual control process completed successfully!")
        except subprocess.CalledProcessError as e:
            print("Error:", e)
    
    def reset_home_page(self):
        self.quiz_shown = False
        self.refresh_home_page()

    def show_quiz(self):
        if not self.quiz_shown: 
            scenario_name = self.scenario_combobox.get()
            questions, autonomy_level = self.load_quiz_data(scenario_name)

            if questions:
                quiz_page = QuizPage(self.root, questions, on_submit=self.reset_home_page, 
                                    scenario_name=scenario_name, autonomy_level=autonomy_level, 
                                    scenario_completed=True)  # Assuming it's completed, implement properly in future

                self.quiz_data_handler = QuizData() 
                quiz_page.quiz_data_handler = self.quiz_data_handler 
                self.quiz_shown = True
            else:
                print(f"No quiz data found for {scenario_name}") 
                
    def refresh_home_page(self):
        # Refresh the home page by destroying all widgets and reinitializing the HomePage class
        for widget in self.root.winfo_children():
            widget.destroy()
        self.__init__(self.root)

    def load_quiz_data(self, scenario_name):
        # Load quiz data from JSON file corresponding to the scenario name
        quiz_file = f"srunner/sagat/{scenario_name}.json"
        if os.path.exists(quiz_file):
            with open(quiz_file, "r") as file:
                quiz_data = json.load(file)
                autonomy_level = quiz_data.get('autonomy_level', None)
            return quiz_data['questions'], autonomy_level
        else:
            print(f"No quiz data found for {scenario_name}")
            return None, None

if __name__ == "__main__":
    root = tk.Tk()
    app = HomePage(root)
    # Center the window on the screen
    root.eval('tk::PlaceWindow . center')
    root.mainloop()